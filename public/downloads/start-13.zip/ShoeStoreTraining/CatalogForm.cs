namespace ShoeStoreTraining;
public partial class CatalogForm : Form
{
public CatalogForm() { InitializeComponent();  }
private void btnShowProduct_Click(object? sender, EventArgs e)
{
Product shoes = new Product(
    "Кроссовки", "SportLine", "Спортивная", 4000m, 5);

decimal finalPrice = shoes.GetDiscountedPrice(25m);
bool sold = shoes.TrySell(2);

lblCatalogResult.Text =
    $"Цена со скидкой: {finalPrice:N2} ₽" + Environment.NewLine +
    $"Продажа выполнена: {sold}" + Environment.NewLine +
    $"Остаток: {shoes.Stock}" + Environment.NewLine +
    $"Малый остаток: {shoes.IsLowStock()}";
}

private readonly List<Product> _products = new List<Product>();
private void btnLoadCatalog_Click(object? sender, EventArgs e)
{
if (_products.Count == 0)
{
    _products.Add(new Product("Кроссовки", "SportLine",
        "Спортивная", 4000m, 2));
    _products.Add(new Product("Ботинки", "NordStep",
        "Зимняя", 5200m, 7));
    _products.Add(new Product("Сандалии", "Sunny",
        "Летняя", 2500m, 0));
}

lstCatalog.Items.Clear();

foreach (Product item in _products)
{
    lstCatalog.Items.Add(
        $"{item.Name} — {item.Price:N2} ₽ — {item.Stock} шт.");
}

lblCatalogSummary.Text = $"Товарных позиций: {_products.Count}";
}

}