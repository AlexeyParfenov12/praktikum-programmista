#nullable enable
namespace ShoeStoreTraining;
partial class CatalogForm
{
private System.ComponentModel.IContainer? components = null;
protected override void Dispose(bool disposing) { if (disposing) components?.Dispose(); base.Dispose(disposing); }
private void InitializeComponent()
{
SuspendLayout();
btnShowProduct = new Button();
btnShowProduct.Name = "btnShowProduct";
btnShowProduct.Location = new Point(20, 20);
btnShowProduct.Size = new Size(430, 35);
btnShowProduct.Text = "Показать товар";
btnShowProduct.Click += btnShowProduct_Click;
Controls.Add(btnShowProduct);
lblCatalogResult = new Label();
lblCatalogResult.Name = "lblCatalogResult";
lblCatalogResult.Location = new Point(480, 20);
lblCatalogResult.Size = new Size(430, 85);
lblCatalogResult.Text = "lblCatalogResult";
Controls.Add(lblCatalogResult);
lstCatalog = new ListBox();
lstCatalog.Name = "lstCatalog";
lstCatalog.Location = new Point(20, 125);
lstCatalog.Size = new Size(430, 80);
Controls.Add(lstCatalog);
btnLoadCatalog = new Button();
btnLoadCatalog.Name = "btnLoadCatalog";
btnLoadCatalog.Location = new Point(480, 125);
btnLoadCatalog.Size = new Size(430, 35);
btnLoadCatalog.Text = "Загрузить каталог";
btnLoadCatalog.Click += btnLoadCatalog_Click;
Controls.Add(btnLoadCatalog);
lblCatalogSummary = new Label();
lblCatalogSummary.Name = "lblCatalogSummary";
lblCatalogSummary.Location = new Point(20, 230);
lblCatalogSummary.Size = new Size(430, 85);
lblCatalogSummary.Text = "lblCatalogSummary";
Controls.Add(lblCatalogSummary);
AutoScroll = true;
ClientSize = new Size(960, 700);
Text = "CatalogForm — восстановительная база";
ResumeLayout(false);
}
private Button btnShowProduct = null!;
private Label lblCatalogResult = null!;
private ListBox lstCatalog = null!;
private Button btnLoadCatalog = null!;
private Label lblCatalogSummary = null!;
}