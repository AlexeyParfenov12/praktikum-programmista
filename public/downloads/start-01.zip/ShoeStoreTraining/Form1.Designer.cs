#nullable enable
namespace ShoeStoreTraining;
partial class Form1
{
private System.ComponentModel.IContainer? components = null;
protected override void Dispose(bool disposing) { if (disposing) components?.Dispose(); base.Dispose(disposing); }
private void InitializeComponent()
{
SuspendLayout();
AutoScroll = true;
ClientSize = new Size(960, 700);
Text = "Form1 — восстановительная база";
ResumeLayout(false);
}

}