namespace ShoeStoreTraining;
public partial class CatalogForm : Form
{
public CatalogForm() { InitializeComponent();  }
private void btnShowProduct_Click(object? sender, EventArgs e)
{
Product first = new Product();
first.Name = "Кроссовки";
first.Price = 4000m;

lblCatalogResult.Text =
    $"Товар: {first.Name}\nЦена: {first.Price:N2} ₽";
}

}