namespace ShoeStoreTraining;
public partial class Form1 : Form
{
public Form1() { InitializeComponent();  }
private void btnStart_Click(object? sender, EventArgs e)
{
lblOutput.Text = "Приложение работает!"; btnStart.Text = "Готово";
}
private void btnShowProduct_Click(object? sender, EventArgs e)
{
string name = txtProductName.Text.Trim();

if (string.IsNullOrWhiteSpace(name))
{
    lblOutput.Text = "Ошибка: укажите название товара";
    return;
}

lblOutput.Text = $"Товар: {name}";
}
private void btnProductInfo_Click(object? sender, EventArgs e)
{
string name = txtProductName.Text.Trim();
decimal price = nudPrice.Value;
int quantity = (int)nudQuantity.Value;

lblOutput.Text =
    $"Товар: {name}; цена: {price:N2} ₽; количество: {quantity} шт.";
}
private void btnTotal_Click(object? sender, EventArgs e)
{
decimal price = nudPrice.Value;
int quantity = (int)nudQuantity.Value;
decimal discount = nudDiscount.Value;

decimal subtotal = price * quantity;
decimal discountSum = subtotal * discount / 100m;
decimal total = subtotal - discountSum;

total = decimal.Round(total, 2, MidpointRounding.AwayFromZero);

lblTotal.Text =
    $"Без скидки: {subtotal:N2} ₽; скидка: {discountSum:N2} ₽; итог: {total:N2} ₽";
}
private void btnCheckStock_Click(object? sender, EventArgs e)
{
int stock = (int)nudStock.Value;
int requested = (int)nudQuantity.Value;

if (stock == 0)
{
    lblStock.Text = "Нет на складе";
    lblStock.BackColor = Color.MistyRose;
}
else if (requested > stock)
{
    lblStock.Text = "Недостаточный остаток";
    lblStock.BackColor = Color.MistyRose;
}
else if (stock <= 3)
{
    lblStock.Text = "Осталось мало — заказ допустим";
    lblStock.BackColor = Color.LightYellow;
}
else
{
    lblStock.Text = "Товар в наличии";
    lblStock.BackColor = SystemColors.Control;
}
}
private void btnCategory_Click(object? sender, EventArgs e)
{
string category = cmbCategory.Text;
string description;

switch (category)
{
    case "Кроссовки":
        description = "Спортивная обувь";
        break;
    case "Ботинки":
        description = "Обувь для прохладной погоды";
        break;
    case "Туфли":
        description = "Повседневная или классическая обувь";
        break;
    default:
        description = "Выберите категорию";
        break;
}

lblOutput.Text = description;
}
private void btnValidate_Click(object? sender, EventArgs e)
{
string article = txtArticle.Text.Trim().ToUpperInvariant();
string stockText = txtStockInput.Text.Trim();

if (article.Length < 4)
{
    lblValidation.Text = "Ошибка: артикул короче 4 символов";
    return;
}

if (!int.TryParse(stockText, out int stock))
{
    lblValidation.Text = "Ошибка: остаток должен быть целым числом";
    return;
}

if (stock < 0)
{
    lblValidation.Text = "Ошибка: остаток не может быть отрицательным";
    return;
}

lblValidation.Text = $"Артикул {article}; остаток {stock} шт.";
}
private void btnLoadProducts_Click(object? sender, EventArgs e)
{
List<string> products = new List<string>
{
    "Кроссовки", "Ботинки", "Туфли", "Сандалии"
};

lstProducts.Items.Clear();

foreach (string product in products)
{
    lstProducts.Items.Add(product);
}

lblSummary.Text = $"Товарных позиций: {products.Count}";
}
private void btnAnalyze_Click(object? sender, EventArgs e)
{
int[] stocks = { 2, 8, 0, 12 };
int totalStock = 0;

for (int i = 0; i < stocks.Length; i++)
{
    totalStock += stocks[i];
}

lblSummary.Text = $"Всего единиц на складе: {totalStock}";
int index = 0;
int emptyProducts = 0;

while (index < stocks.Length)
{
    if (stocks[index] == 0)
    {
        emptyProducts++;
    }

    index++;
}

lblSummary.Text += $"; нет в наличии: {emptyProducts}";
}

}