namespace ShoeStoreTraining;
internal static class Program { [STAThread] static void Main() { ApplicationConfiguration.Initialize(); Application.Run(new CatalogForm()); } }