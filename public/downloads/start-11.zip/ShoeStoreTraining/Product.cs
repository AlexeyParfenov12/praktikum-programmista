namespace ShoeStoreTraining;

public class Product
{
    public string Name { get; set; }
    public string Manufacturer { get; set; }
    public decimal Price { get; set; }
    public int Stock { get; set; }

    public Product(string name, string manufacturer,
                   decimal price, int stock)
    {
        Name = name;
        Manufacturer = manufacturer;
        Price = price;
        Stock = stock;
    }
}