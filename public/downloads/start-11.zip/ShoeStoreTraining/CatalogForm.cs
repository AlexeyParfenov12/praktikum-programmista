namespace ShoeStoreTraining;
public partial class CatalogForm : Form
{
public CatalogForm() { InitializeComponent();  }
private void btnShowProduct_Click(object? sender, EventArgs e)
{
Product first = new Product("Кроссовки", "SportLine", 4000m, 2);
Product second = new Product("Ботинки", "NordStep", 5200m, 7);

lblCatalogResult.Text =
    $"{first.Name} ({first.Manufacturer}): {first.Price:N2} ₽, {first.Stock} шт." +
    Environment.NewLine +
    $"{second.Name} ({second.Manufacturer}): {second.Price:N2} ₽, {second.Stock} шт.";
}

}