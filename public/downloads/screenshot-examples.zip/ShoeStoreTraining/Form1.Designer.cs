namespace ShoeStoreTraining;
partial class Form1
{
private void InitializeComponent()
{
SuspendLayout();
lblTitle = new Label();
lblTitle.Name = "lblTitle";
lblTitle.Text = "Магазин обуви — первый запуск";
lblTitle.Location = new Point(28, 22);
lblTitle.Size = new Size(760, 40);
Controls.Add(lblTitle);
btnStart = new Button();
btnStart.Name = "btnStart";
btnStart.Text = "Запустить";
btnStart.Location = new Point(30, 100);
btnStart.Size = new Size(170, 36);
Controls.Add(btnStart);
lblOutput = new Label();
lblOutput.Name = "lblOutput";
lblOutput.Text = "Здесь появится результат";
lblOutput.Location = new Point(30, 160);
lblOutput.Size = new Size(740, 65);
Controls.Add(lblOutput);
btnReset = new Button();
btnReset.Name = "btnReset";
btnReset.Text = "Сброс";
btnReset.Location = new Point(30, 240);
btnReset.Size = new Size(170, 36);
Controls.Add(btnReset);
btnStart.Click += btnStart_Click;
btnReset.Click += btnReset_Click;
ClientSize = new Size(820,560);
Font = new Font("Segoe UI", 11F);
Text = "ShoeStore | Тренировочный проект · Практическая №1";
StartPosition = FormStartPosition.CenterScreen;
ResumeLayout(false);
PerformLayout();
}
private Label lblTitle = null!;
private Button btnStart = null!;
private Label lblOutput = null!;
private Button btnReset = null!;
}