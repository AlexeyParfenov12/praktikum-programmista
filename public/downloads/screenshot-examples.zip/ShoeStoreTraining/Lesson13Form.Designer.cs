namespace ShoeStoreTraining;
partial class Lesson13Form
{
    private void InitializeComponent()
    {
        lblTitle = new Label();
        dgvProducts = new DataGridView();
        btnShowTable = new Button();
        btnDetails = new Button();
        lblSelectedProduct = new Label();
        dataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
        dataGridViewTextBoxColumn2 = new DataGridViewTextBoxColumn();
        dataGridViewTextBoxColumn3 = new DataGridViewTextBoxColumn();
        dataGridViewTextBoxColumn4 = new DataGridViewTextBoxColumn();
        dataGridViewTextBoxColumn5 = new DataGridViewTextBoxColumn();
        dataGridViewTextBoxColumn6 = new DataGridViewTextBoxColumn();
        ((System.ComponentModel.ISupportInitialize)dgvProducts).BeginInit();
        SuspendLayout();
        // 
        // lblTitle
        // 
        lblTitle.Location = new Point(28, 22);
        lblTitle.Name = "lblTitle";
        lblTitle.Size = new Size(760, 40);
        lblTitle.TabIndex = 0;
        lblTitle.Text = "Каталог товаров";
        // 
        // dgvProducts
        // 
        dgvProducts.AllowUserToAddRows = false;
        dgvProducts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        dgvProducts.ColumnHeadersHeight = 60;
        dgvProducts.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn1, dataGridViewTextBoxColumn2, dataGridViewTextBoxColumn3, dataGridViewTextBoxColumn4, dataGridViewTextBoxColumn5, dataGridViewTextBoxColumn6 });
        dgvProducts.Location = new Point(25, 85);
        dgvProducts.Name = "dgvProducts";
        dgvProducts.RowHeadersVisible = false;
        dgvProducts.RowHeadersWidth = 51;
        dgvProducts.Size = new Size(785, 260);
        dgvProducts.TabIndex = 1;
        // 
        // btnShowTable
        // 
        btnShowTable.Location = new Point(25, 365);
        btnShowTable.Name = "btnShowTable";
        btnShowTable.Size = new Size(190, 36);
        btnShowTable.TabIndex = 2;
        btnShowTable.Text = "Обновить таблицу";
        btnShowTable.Click += btnShowTable_Click;
        // 
        // btnDetails
        // 
        btnDetails.Location = new Point(235, 365);
        btnDetails.Name = "btnDetails";
        btnDetails.Size = new Size(140, 36);
        btnDetails.TabIndex = 3;
        btnDetails.Text = "Карточка";
        // 
        // lblSelectedProduct
        // 
        lblSelectedProduct.Location = new Point(25, 415);
        lblSelectedProduct.Name = "lblSelectedProduct";
        lblSelectedProduct.Size = new Size(600, 30);
        lblSelectedProduct.TabIndex = 4;
        lblSelectedProduct.Text = "Выберите товар в таблице";
        // 
        // dataGridViewTextBoxColumn1
        // 
        dataGridViewTextBoxColumn1.HeaderText = "Товар";
        dataGridViewTextBoxColumn1.MinimumWidth = 6;
        dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
        // 
        // dataGridViewTextBoxColumn2
        // 
        dataGridViewTextBoxColumn2.HeaderText = "Производитель";
        dataGridViewTextBoxColumn2.MinimumWidth = 6;
        dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
        // 
        // dataGridViewTextBoxColumn3
        // 
        dataGridViewTextBoxColumn3.HeaderText = "Категория";
        dataGridViewTextBoxColumn3.MinimumWidth = 6;
        dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
        // 
        // dataGridViewTextBoxColumn4
        // 
        dataGridViewTextBoxColumn4.HeaderText = "Начальная цена";
        dataGridViewTextBoxColumn4.MinimumWidth = 6;
        dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
        // 
        // dataGridViewTextBoxColumn5
        // 
        dataGridViewTextBoxColumn5.HeaderText = "Цена со скидкой";
        dataGridViewTextBoxColumn5.MinimumWidth = 6;
        dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
        // 
        // dataGridViewTextBoxColumn6
        // 
        dataGridViewTextBoxColumn6.HeaderText = "Остаток";
        dataGridViewTextBoxColumn6.MinimumWidth = 6;
        dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
        // 
        // Lesson13Form
        // 
        ClientSize = new Size(820, 560);
        Controls.Add(lblTitle);
        Controls.Add(dgvProducts);
        Controls.Add(btnShowTable);
        Controls.Add(btnDetails);
        Controls.Add(lblSelectedProduct);
        Font = new Font("Segoe UI", 11F);
        Name = "Lesson13Form";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "CatalogForm · Практическая №13";
        ((System.ComponentModel.ISupportInitialize)dgvProducts).EndInit();
        ResumeLayout(false);
    }
    private Label lblTitle = null!;
private DataGridView dgvProducts = null!;
private Button btnShowTable = null!;
private Button btnDetails = null!;
private Label lblSelectedProduct = null!;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
}
