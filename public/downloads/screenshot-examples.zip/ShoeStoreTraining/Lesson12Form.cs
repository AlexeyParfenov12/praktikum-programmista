namespace ShoeStoreTraining;

public partial class Lesson12Form : Form
{
    public Lesson12Form()
    {
        InitializeComponent();
    }

    private void btnLoadCatalog_Click(object? sender, EventArgs e)
    {
        List<Product> products = new List<Product>
        {
            new Product("Кроссовки", "SportLine", 4000m, 5, "Спортивная"),
            new Product("Ботинки", "NordStep", 5200m, 7, "Зимняя"),
            new Product("Сандалии", "Sunny", 2500m, 4, "Летняя"),
            new Product("Туфли", "CityWalk", 3100m, 3, "Классическая"),
            new Product("Кеды", "SportLine", 2800m, 12, "Спортивная")
        };
        lstCatalog.Items.Clear();
        decimal inventoryValue = 0m;
        foreach (Product item in products)
        {
            lstCatalog.Items.Add($"{item.Name}: {item.Stock} шт.");
            inventoryValue += item.Price * item.Stock;
        }
        lblCatalogSummary.Text = $"Позиций: {products.Count}; стоимость: {inventoryValue:N2} ₽";
    }

}
