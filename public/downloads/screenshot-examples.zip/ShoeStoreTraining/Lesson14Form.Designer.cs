namespace ShoeStoreTraining;
partial class Lesson14Form
{
private void InitializeComponent()
{
SuspendLayout();
lblTitle = new Label();
lblTitle.Name = "lblTitle";
lblTitle.Text = "Карточка выбранного товара";
lblTitle.Location = new Point(28, 22);
lblTitle.Size = new Size(760, 40);
Controls.Add(lblTitle);
lblDetails = new Label();
lblDetails.Name = "lblDetails";
lblDetails.Text = "Данные переданного Product появятся здесь";
lblDetails.Location = new Point(30, 100);
lblDetails.Size = new Size(740, 220);
Controls.Add(lblDetails);
lblStatus = new Label();
lblStatus.Name = "lblStatus";
lblStatus.Text = "Статус товара";
lblStatus.Location = new Point(30, 345);
lblStatus.Size = new Size(600, 30);
Controls.Add(lblStatus);
btnClose = new Button();
btnClose.Name = "btnClose";
btnClose.Text = "Закрыть";
btnClose.Location = new Point(30, 420);
btnClose.Size = new Size(170, 36);
Controls.Add(btnClose);
btnClose.Click += btnClose_Click;
ClientSize = new Size(820,560);
Font = new Font("Segoe UI", 11F);
Text = "ProductDetailsForm · Практическая №14";
StartPosition = FormStartPosition.CenterScreen;
ResumeLayout(false);
PerformLayout();
}
private Label lblTitle = null!;
private Label lblDetails = null!;
private Label lblStatus = null!;
private Button btnClose = null!;
}
