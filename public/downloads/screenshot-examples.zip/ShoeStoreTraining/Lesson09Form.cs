namespace ShoeStoreTraining;

public partial class Lesson09Form : Form
{
    public Lesson09Form()
    {
        InitializeComponent();
    }

    private void btnShowProduct_Click(object? sender, EventArgs e)
    {
        Product first = new Product();
        first.Name = "Кроссовки";
        first.Price = 4000m;
        first.Stock = 2;
        Product second = new Product();
        second.Name = "Ботинки";
        second.Price = 5200m;
        second.Stock = 7;
        lblCatalogResult.Text = $"{first.Name}: {first.Price:N2} ₽; {first.Stock} шт." + Environment.NewLine + $"{second.Name}: {second.Price:N2} ₽; {second.Stock} шт.";
    }

}
