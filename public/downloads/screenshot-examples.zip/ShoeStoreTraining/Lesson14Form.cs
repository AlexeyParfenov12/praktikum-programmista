namespace ShoeStoreTraining;
public partial class Lesson14Form : Form
{
    public Lesson14Form() : this(new Product("Кроссовки", "SportLine", 4000m, 2, "Спортивная")) { }
    public Lesson14Form(Product product)
    {
        InitializeComponent();
        lblDetails.Text = $"Наименование: {product.Name}" + Environment.NewLine +
            $"Производитель: {product.Manufacturer}" + Environment.NewLine +
            $"Категория: {product.Category}" + Environment.NewLine +
            $"Обычная цена: {product.Price:N2} ₽" + Environment.NewLine +
            $"Цена со скидкой: {product.GetDiscountedPrice(25m):N2} ₽" + Environment.NewLine +
            $"Остаток: {product.Stock} шт.";
        if (product.IsLowStock()) lblStatus.Text = "Низкий остаток";
        else lblStatus.Text = "Достаточный остаток";
    }
    private void btnClose_Click(object? sender, EventArgs e) { Close(); }
}