namespace ShoeStoreTraining;

public partial class Lesson11Form : Form
{
    public Lesson11Form()
    {
        InitializeComponent();
    }

    private void btnShowProduct_Click(object? sender, EventArgs e)
    {
        Product boots = new Product("Ботинки", "NordStep", 6000m, 2, "Зимняя");
        bool refused = boots.TrySell(3);
        int afterRefusal = boots.Stock;
        bool sold = boots.TrySell(1);
        int afterSuccess = boots.Stock;
        bool restocked = boots.Restock(4);
        bool negative = boots.Restock(-1);
        lblCatalogResult.Text = $"TrySell(3): {refused}; Stock = {afterRefusal}" + Environment.NewLine + $"TrySell(1): {sold}; Stock = {afterSuccess}" + Environment.NewLine + $"Restock(4): {restocked}; Stock = {boots.Stock}" + Environment.NewLine + $"Restock(-1): {negative}";
    }

}
