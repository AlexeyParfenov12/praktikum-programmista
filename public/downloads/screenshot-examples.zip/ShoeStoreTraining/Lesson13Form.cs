namespace ShoeStoreTraining;

public partial class Lesson13Form : Form
{
    public Lesson13Form()
    {
        InitializeComponent();
    }

    private void btnShowTable_Click(object? sender, EventArgs e)
    {
        dgvProducts.Rows.Clear();
        int index = dgvProducts.Rows.Add("Кроссовки", "SportLine", "Спортивная", "4000", "3000", "2");
        dgvProducts.Rows[index].Tag = new Product("Кроссовки", "SportLine", 4000m, 2, "Спортивная");
        dgvProducts.Rows[index].DefaultCellStyle.BackColor = Color.MistyRose;
        lblSelectedProduct.Text = "Выбран товар: Кроссовки";
    }

}
