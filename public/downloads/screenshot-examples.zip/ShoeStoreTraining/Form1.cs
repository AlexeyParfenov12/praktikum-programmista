namespace ShoeStoreTraining;

public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
    }

    private void btnStart_Click(object? sender, EventArgs e)
    {
        lblOutput.Text = "Приложение работает!";
        btnStart.Text = "Готово";
    }
private void btnReset_Click(object? sender, EventArgs e) { lblOutput.Text = "Здесь появится результат"; btnStart.Text = "Запустить"; }
}
