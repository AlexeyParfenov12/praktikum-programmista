namespace ShoeStoreTraining;
public class Product
{
 public string Name { get; set; } = "";
 public string Manufacturer { get; set; } = "";
 public string Category { get; set; } = "";
 public decimal Price { get; set; }
 public int Stock { get; set; }
 public Product() {}
 public Product(string name,string manufacturer,decimal price,int stock,string category)
 { Name=name; Manufacturer=manufacturer; Price=price; Stock=stock; Category=category; }
 public bool TrySell(int quantity)
 { if(quantity<=0 || quantity>Stock)return false; Stock-=quantity; return true; }
 public bool Restock(int quantity)
 { if(quantity<=0)return false; Stock+=quantity; return true; }
 public decimal GetDiscountedPrice(decimal discount) {return Price*(100m-discount)/100m;}
 public bool IsLowStock() {return Stock<=3;}
}