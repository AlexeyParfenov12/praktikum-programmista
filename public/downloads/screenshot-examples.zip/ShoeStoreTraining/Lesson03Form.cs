namespace ShoeStoreTraining;

public partial class Lesson03Form : Form
{
    public Lesson03Form()
    {
        InitializeComponent();
    }

    private void btnProductInfo_Click(object? sender, EventArgs e)
    {
        string name = txtProductName.Text.Trim();
        if (string.IsNullOrWhiteSpace(name)) { lblOutput.Text = "Введите название"; return; }
        decimal price = nudPrice.Value;
        int quantity = (int)nudQuantity.Value;
        int stock = (int)nudStock.Value;
        bool isAvailable = quantity > 0;
        lblOutput.Text = $"Товар: {name}; цена: {price:N2}; заказано: {quantity}; остаток: {stock}; доступен: {isAvailable}";
    }

}
