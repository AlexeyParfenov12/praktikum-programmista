namespace ShoeStoreTraining;

public partial class Lesson06Form : Form
{
    public Lesson06Form()
    {
        InitializeComponent();
    }

    private void btnValidate_Click(object? sender, EventArgs e)
    {
        string name = txtProductName.Text.Trim();
        string article = txtArticle.Text.Trim().ToUpperInvariant();
        if (string.IsNullOrWhiteSpace(name)) { lblValidation.Text = "Введите название"; return; }
        if (article.Length < 4 || article.Contains(" ")) { lblValidation.Text = "Проверьте артикул"; return; }
        if (!int.TryParse(txtStockInput.Text, out int stock) || stock < 0 || stock > nudStock.Maximum)
        {
            lblValidation.Text = "Некорректный остаток";
            return;
        }
        nudStock.Value = stock;
        lblValidation.Text = $"Артикул {article}; остаток {stock} шт.";
    }

}
