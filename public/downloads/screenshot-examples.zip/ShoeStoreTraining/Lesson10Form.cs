namespace ShoeStoreTraining;

public partial class Lesson10Form : Form
{
    public Lesson10Form()
    {
        InitializeComponent();
    }

    private void btnShowProduct_Click(object? sender, EventArgs e)
    {
        Product first = new Product("Кроссовки", "SportLine", 4000m, 2, "Спортивная");
        Product second = new Product("Ботинки", "NordStep", 5200m, 7, "Зимняя");
        Product third = new Product("Сандалии", "Sunny", 2500m, 4, "Летняя");
        lblCatalogResult.Text = $"{first.Name}, {first.Category}" + Environment.NewLine + $"{second.Name}, {second.Category}" + Environment.NewLine + $"{third.Name}, {third.Category}";
    }

}
