namespace ShoeStoreTraining;

public partial class Lesson16Form : Form
{
    public Lesson16Form()
    {
        InitializeComponent();
        dgvProducts.ColumnHeadersHeight = 60;
    }

    private void btnShowTable_Click(object? sender, EventArgs e)
    {
        dgvProducts.Rows.Clear();
        dgvProducts.Rows.Add("Футбольный мяч", "GoalPro", "Мячи", "2200", "1980", "2");
        dgvProducts.Rows.Add("Баскетбольный мяч", "SportMax", "Мячи", "3100", "2790", "7");
        dgvProducts.Rows.Add("Теннисная ракетка", "AceLine", "Ракетки", "4800", "4320", "0");
        dgvProducts.Rows.Add("Перчатки вратаря", "Keeper", "Экипировка", "1900", "1710", "5");
        dgvProducts.Rows.Add("Набор фишек", "TrainKit", "Инвентарь", "1200", "1080", "11");
        foreach (DataGridViewRow row in dgvProducts.Rows)
        {
            if (int.Parse(row.Cells[5].Value.ToString()!) <= 3) row.DefaultCellStyle.BackColor = Color.MistyRose;
        }
    }

}
