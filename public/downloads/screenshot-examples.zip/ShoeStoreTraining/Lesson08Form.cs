namespace ShoeStoreTraining;

public partial class Lesson08Form : Form
{
    public Lesson08Form()
    {
        InitializeComponent();
    }

    private void btnTotal_Click(object? sender, EventArgs e)
    {
        decimal price = nudPrice.Value;
        int quantity = (int)nudQuantity.Value;
        decimal discount = nudDiscount.Value;
        decimal result = CalculateTotal(price, quantity, discount);
        lblTotal.Text = $"К оплате: {result:N2} ₽";
    }
private decimal CalculateTotal(decimal price, int quantity, decimal discount) { return decimal.Round(price * quantity * (100m-discount)/100m, 2); }
}
