namespace ShoeStoreTraining;

public partial class Lesson05Form : Form
{
    public Lesson05Form()
    {
        InitializeComponent();
    }

    private void btnTotal_Click(object? sender, EventArgs e)
    {
        int stock = (int)nudStock.Value;
        int requested = (int)nudQuantity.Value;
        if (requested > stock)
        {
            MessageBox.Show("Недостаточно товара");
            return;
        }
        if (stock == 0) { lblStock.Text = "Нет на складе"; } else if (requested == stock) { lblStock.Text = "После заказа запас закончится"; } else { lblStock.Text = "Товар в наличии"; }
    }

}

