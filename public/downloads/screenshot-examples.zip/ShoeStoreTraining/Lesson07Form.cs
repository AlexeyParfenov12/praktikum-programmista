namespace ShoeStoreTraining;

public partial class Lesson07Form : Form
{
    public Lesson07Form()
    {
        InitializeComponent();
    }

    private void btnLoadProducts_Click(object? sender, EventArgs e)
    {
        lstProducts.Items.Clear();
        lstProducts.Items.AddRange(new object[] { "Кроссовки", "Ботинки", "Туфли", "Сандалии", "Кеды", "Мокасины", "Сапоги" });
        int[] stocks = { 2, 8, 0, 12, 5, 1, 3 };
        int total = 0;
        int zero = 0;
        int low = 0;
        for (int i = 0; i < stocks.Length; i++)
        {
            total += stocks[i];
            if (stocks[i] == 0) zero++;
            if (stocks[i] >= 1 && stocks[i] <= 3) low++;
        }
        lblSummary.Text = $"Сумма: {total}; нулевых: {zero}; от 1 до 3: {low}";
    }

}
