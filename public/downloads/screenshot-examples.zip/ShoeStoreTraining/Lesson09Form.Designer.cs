namespace ShoeStoreTraining;
partial class Lesson09Form
{
private void InitializeComponent()
{
SuspendLayout();
lblTitle = new Label();
lblTitle.Name = "lblTitle";
lblTitle.Text = "Учебный магазин обуви";
lblTitle.Location = new Point(28, 22);
lblTitle.Size = new Size(760, 40);
Controls.Add(lblTitle);
btnShowProduct = new Button();
btnShowProduct.Name = "btnShowProduct";
btnShowProduct.Text = "Показать товары";
btnShowProduct.Location = new Point(30, 90);
btnShowProduct.Size = new Size(220, 36);
Controls.Add(btnShowProduct);
lblCatalogResult = new Label();
lblCatalogResult.Name = "lblCatalogResult";
lblCatalogResult.Text = "Здесь появятся карточки товаров";
lblCatalogResult.Location = new Point(30, 160);
lblCatalogResult.Size = new Size(760, 320);
Controls.Add(lblCatalogResult);
btnShowProduct.Click += btnShowProduct_Click;
ClientSize = new Size(820,560);
Font = new Font("Segoe UI", 11F);
Text = "CatalogForm · Практическая №9";
StartPosition = FormStartPosition.CenterScreen;
ResumeLayout(false);
PerformLayout();
}
private Label lblTitle = null!;
private Button btnShowProduct = null!;
private Label lblCatalogResult = null!;
}
