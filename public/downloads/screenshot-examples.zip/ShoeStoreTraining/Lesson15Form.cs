namespace ShoeStoreTraining;

public partial class Lesson15Form : Form
{
    public Lesson15Form()
    {
        InitializeComponent();
        btnAddProduct.Click += AddProduct;
        btnDetails.Click += (_, _) => { if (dgvProducts.CurrentRow?.Tag is Product p) { using var details = new Lesson14Form(p); details.ShowDialog(this); } };
        dgvProducts.ColumnHeadersHeight = 60;
    }

    private void btnShowTable_Click(object? sender, EventArgs e)
    {
        dgvProducts.Rows.Clear();
        dgvProducts.Rows.Add("Кроссовки", "SportLine", "Спортивная", "4000", "3000", "2");
        lblAddStatus.Text = "Проверьте ввод перед добавлением";
        dgvProducts.Rows[0].Tag = new Product("Кроссовки", "SportLine", 4000m, 2, "Спортивная");
    }
    private void AddProduct(object? sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtNewName.Text) ||
            !decimal.TryParse(txtNewPrice.Text, out decimal price) || price <= 0 ||
            !int.TryParse(txtNewStock.Text, out int stock) || stock < 0)
        { lblAddStatus.Text = "Проверьте название, цену и остаток"; return; }
        Product item = new Product(txtNewName.Text.Trim(), "Учебный", price, stock, "Обувь");
        int row = dgvProducts.Rows.Add(item.Name, item.Manufacturer, item.Category,
            item.Price, item.GetDiscountedPrice(25m), item.Stock);
        dgvProducts.Rows[row].Tag = item;
        txtNewName.Clear(); txtNewPrice.Clear(); txtNewStock.Clear();
        lblAddStatus.Text = $"Товар добавлен. Позиций: {dgvProducts.Rows.Count}";
    }
}
