namespace ShoeStoreTraining;
internal static class Program
{
 [STAThread] static void Main() { ApplicationConfiguration.Initialize(); Application.Run(new ExamplesMenu()); }
}
public class ExamplesMenu : Form
{
 public ExamplesMenu()
 {
  Text = "Примеры со скриншотов — выберите занятие"; Width = 700; Height = 600;
  FlowLayoutPanel menu = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoScroll = true };
  Controls.Add(menu);
  for (int i=1; i<=16; i++)
  {
   int lesson=i;
   Button button = new Button { Text = $"Пример {lesson:00}", Width = 145, Height = 70 };
   button.Click += (_, _) => { using Form example = CreateExample(lesson); example.ShowDialog(this); };
   menu.Controls.Add(button);
  }
 }
 private static Form CreateExample(int lesson) => lesson switch
 {
  1 => new Form1(), 2 => new Lesson02Form(), 3 => new Lesson03Form(), 4 => new Lesson04Form(),
  5 => new Lesson05Form(), 6 => new Lesson06Form(), 7 => new Lesson07Form(), 8 => new Lesson08Form(),
  9 => new Lesson09Form(), 10 => new Lesson10Form(), 11 => new Lesson11Form(), 12 => new Lesson12Form(),
  13 => new Lesson13Form(), 14 => new Lesson14Form(), 15 => new Lesson15Form(), _ => new Lesson16Form()
 };
}
