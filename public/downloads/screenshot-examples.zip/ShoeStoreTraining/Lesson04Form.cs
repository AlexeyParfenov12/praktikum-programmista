namespace ShoeStoreTraining;

public partial class Lesson04Form : Form
{
    public Lesson04Form()
    {
        InitializeComponent();
    }

    private void btnTotal_Click(object? sender, EventArgs e)
    {
        decimal price = nudPrice.Value;
        int quantity = (int)nudQuantity.Value;
        decimal discount = nudDiscount.Value;
        decimal subtotal = price * quantity;
        decimal discountSum = subtotal * discount / 100m;
        decimal total = subtotal - discountSum;
        lblDiscountSum.Text = $"{discountSum:N2} ₽";
        lblTotal.Text = $"К оплате: {total:N2} ₽";
    }
private void btnWithoutDiscount_Click(object? sender, EventArgs e) { nudDiscount.Value = 0; btnTotal.PerformClick(); }
}
