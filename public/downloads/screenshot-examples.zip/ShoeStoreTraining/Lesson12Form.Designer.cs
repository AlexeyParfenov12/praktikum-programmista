namespace ShoeStoreTraining;
partial class Lesson12Form
{
private void InitializeComponent()
{
SuspendLayout();
lblTitle = new Label();
lblTitle.Name = "lblTitle";
lblTitle.Text = "Учебный магазин обуви";
lblTitle.Location = new Point(28, 22);
lblTitle.Size = new Size(760, 40);
Controls.Add(lblTitle);
btnLoadCatalog = new Button();
btnLoadCatalog.Name = "btnLoadCatalog";
btnLoadCatalog.Text = "Загрузить каталог";
btnLoadCatalog.Location = new Point(30, 90);
btnLoadCatalog.Size = new Size(220, 36);
Controls.Add(btnLoadCatalog);
lstCatalog = new ListBox();
lstCatalog.Name = "lstCatalog";
lstCatalog.Text = "";
lstCatalog.Location = new Point(30, 150);
lstCatalog.Size = new Size(760, 280);
Controls.Add(lstCatalog);
lblCatalogSummary = new Label();
lblCatalogSummary.Name = "lblCatalogSummary";
lblCatalogSummary.Text = "Каталог ещё не загружен";
lblCatalogSummary.Location = new Point(30, 460);
lblCatalogSummary.Size = new Size(760, 60);
Controls.Add(lblCatalogSummary);
btnLoadCatalog.Click += btnLoadCatalog_Click;
ClientSize = new Size(820,560);
Font = new Font("Segoe UI", 11F);
Text = "ShoeStoreTraining · Практическая №12";
StartPosition = FormStartPosition.CenterScreen;
ResumeLayout(false);
PerformLayout();
}
private Label lblTitle = null!;
private Button btnLoadCatalog = null!;
private ListBox lstCatalog = null!;
private Label lblCatalogSummary = null!;
}
