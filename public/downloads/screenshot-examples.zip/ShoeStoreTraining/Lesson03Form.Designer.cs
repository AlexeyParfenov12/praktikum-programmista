namespace ShoeStoreTraining;
partial class Lesson03Form
{
    private void InitializeComponent()
    {
        lblTitle = new Label();
        captionName = new Label();
        txtProductName = new TextBox();
        captionPrice = new Label();
        nudPrice = new NumericUpDown();
        captionQuantity = new Label();
        nudQuantity = new NumericUpDown();
        captionStock = new Label();
        nudStock = new NumericUpDown();
        btnProductInfo = new Button();
        lblOutput = new Label();
        ((System.ComponentModel.ISupportInitialize)nudPrice).BeginInit();
        ((System.ComponentModel.ISupportInitialize)nudQuantity).BeginInit();
        ((System.ComponentModel.ISupportInitialize)nudStock).BeginInit();
        SuspendLayout();
        // 
        // lblTitle
        // 
        lblTitle.Location = new Point(28, 22);
        lblTitle.Name = "lblTitle";
        lblTitle.Size = new Size(760, 40);
        lblTitle.TabIndex = 0;
        lblTitle.Text = "Учебный магазин обуви";
        // 
        // captionName
        // 
        captionName.Location = new Point(30, 86);
        captionName.Name = "captionName";
        captionName.Size = new Size(200, 30);
        captionName.TabIndex = 1;
        captionName.Text = "Название товара";
        // 
        // txtProductName
        // 
        txtProductName.Location = new Point(30, 118);
        txtProductName.Name = "txtProductName";
        txtProductName.Size = new Size(230, 32);
        txtProductName.TabIndex = 2;
        txtProductName.Text = "Кроссовки";
        // 
        // captionPrice
        // 
        captionPrice.Location = new Point(30, 175);
        captionPrice.Name = "captionPrice";
        captionPrice.Size = new Size(150, 30);
        captionPrice.TabIndex = 3;
        captionPrice.Text = "Цена, ₽";
        // 
        // nudPrice
        // 
        nudPrice.Location = new Point(30, 208);
        nudPrice.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
        nudPrice.Name = "nudPrice";
        nudPrice.Size = new Size(160, 32);
        nudPrice.TabIndex = 4;
        nudPrice.Value = new decimal(new int[] { 1000, 0, 0, 0 });
        // 
        // captionQuantity
        // 
        captionQuantity.Location = new Point(235, 175);
        captionQuantity.Name = "captionQuantity";
        captionQuantity.Size = new Size(150, 30);
        captionQuantity.TabIndex = 5;
        captionQuantity.Text = "Количество";
        // 
        // nudQuantity
        // 
        nudQuantity.Location = new Point(235, 208);
        nudQuantity.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
        nudQuantity.Name = "nudQuantity";
        nudQuantity.Size = new Size(160, 32);
        nudQuantity.TabIndex = 6;
        nudQuantity.Value = new decimal(new int[] { 2, 0, 0, 0 });
        // 
        // captionStock
        // 
        captionStock.Location = new Point(440, 175);
        captionStock.Name = "captionStock";
        captionStock.Size = new Size(230, 30);
        captionStock.TabIndex = 7;
        captionStock.Text = "Остаток на складе";
        // 
        // nudStock
        // 
        nudStock.Location = new Point(440, 208);
        nudStock.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
        nudStock.Name = "nudStock";
        nudStock.Size = new Size(160, 32);
        nudStock.TabIndex = 8;
        nudStock.Value = new decimal(new int[] { 8, 0, 0, 0 });
        // 
        // btnProductInfo
        // 
        btnProductInfo.Location = new Point(30, 355);
        btnProductInfo.Name = "btnProductInfo";
        btnProductInfo.Size = new Size(170, 36);
        btnProductInfo.TabIndex = 9;
        btnProductInfo.Text = "Показать карточку";
        btnProductInfo.Click += btnProductInfo_Click;
        // 
        // lblOutput
        // 
        lblOutput.Location = new Point(30, 420);
        lblOutput.Name = "lblOutput";
        lblOutput.Size = new Size(760, 65);
        lblOutput.TabIndex = 10;
        lblOutput.Text = "Здесь появится результат";
        // 
        // Lesson03Form
        // 
        ClientSize = new Size(820, 560);
        Controls.Add(lblTitle);
        Controls.Add(captionName);
        Controls.Add(txtProductName);
        Controls.Add(captionPrice);
        Controls.Add(nudPrice);
        Controls.Add(captionQuantity);
        Controls.Add(nudQuantity);
        Controls.Add(captionStock);
        Controls.Add(nudStock);
        Controls.Add(btnProductInfo);
        Controls.Add(lblOutput);
        Font = new Font("Segoe UI", 11F);
        Name = "Lesson03Form";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "ShoeStoreTraining · Практическая №3";
        ((System.ComponentModel.ISupportInitialize)nudPrice).EndInit();
        ((System.ComponentModel.ISupportInitialize)nudQuantity).EndInit();
        ((System.ComponentModel.ISupportInitialize)nudStock).EndInit();
        ResumeLayout(false);
        PerformLayout();
    }
    private Label lblTitle = null!;
private Label captionName = null!;
private TextBox txtProductName = null!;
private Label captionPrice = null!;
private NumericUpDown nudPrice = null!;
private Label captionQuantity = null!;
private NumericUpDown nudQuantity = null!;
private Label captionStock = null!;
private NumericUpDown nudStock = null!;
private Button btnProductInfo = null!;
private Label lblOutput = null!;
}