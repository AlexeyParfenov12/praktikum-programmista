namespace ShoeStoreTraining;
partial class Lesson07Form
{
private void InitializeComponent()
{
SuspendLayout();
lblTitle = new Label();
lblTitle.Name = "lblTitle";
lblTitle.Text = "Учебный магазин обуви";
lblTitle.Location = new Point(28, 22);
lblTitle.Size = new Size(760, 40);
Controls.Add(lblTitle);
btnLoadProducts = new Button();
btnLoadProducts.Name = "btnLoadProducts";
btnLoadProducts.Text = "Загрузить каталог";
btnLoadProducts.Location = new Point(30, 90);
btnLoadProducts.Size = new Size(220, 36);
Controls.Add(btnLoadProducts);
lstProducts = new ListBox();
lstProducts.Name = "lstProducts";
lstProducts.Text = "";
lstProducts.Location = new Point(30, 150);
lstProducts.Size = new Size(760, 280);
Controls.Add(lstProducts);
lblSummary = new Label();
lblSummary.Name = "lblSummary";
lblSummary.Text = "Каталог ещё не загружен";
lblSummary.Location = new Point(30, 460);
lblSummary.Size = new Size(760, 60);
Controls.Add(lblSummary);
btnLoadProducts.Click += btnLoadProducts_Click;
ClientSize = new Size(820,560);
Font = new Font("Segoe UI", 11F);
Text = "ShoeStoreTraining · Практическая №7";
StartPosition = FormStartPosition.CenterScreen;
ResumeLayout(false);
PerformLayout();
}
private Label lblTitle = null!;
private Button btnLoadProducts = null!;
private ListBox lstProducts = null!;
private Label lblSummary = null!;
}
