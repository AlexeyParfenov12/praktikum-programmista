namespace ShoeStoreTraining;

public partial class Lesson02Form : Form
{
    public Lesson02Form()
    {
        InitializeComponent();
    }

    private void btnProductInfo_Click(object? sender, EventArgs e)
    {
        string name = txtProductName.Text.Trim();
        string manufacturer = txtManufacturer.Text.Trim();
        if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(manufacturer))
        {
            lblOutput.Text = "Заполните название и производителя";
            return;
        }
        lblOutput.Text = $"Товар: {name}; производитель: {manufacturer}";
    }
private void btnClearProduct_Click(object? sender, EventArgs e) { txtProductName.Clear(); txtManufacturer.Clear(); lblOutput.Text = "Введите новый товар"; }
}
