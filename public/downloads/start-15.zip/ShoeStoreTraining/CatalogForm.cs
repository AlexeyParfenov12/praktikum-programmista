namespace ShoeStoreTraining;
public partial class CatalogForm : Form
{
public CatalogForm() { InitializeComponent();  }
private void btnShowProduct_Click(object? sender, EventArgs e)
{
Product shoes = new Product(
    "Кроссовки", "SportLine", "Спортивная", 4000m, 5);

decimal finalPrice = shoes.GetDiscountedPrice(25m);
bool sold = shoes.TrySell(2);

lblCatalogResult.Text =
    $"Цена со скидкой: {finalPrice:N2} ₽" + Environment.NewLine +
    $"Продажа выполнена: {sold}" + Environment.NewLine +
    $"Остаток: {shoes.Stock}" + Environment.NewLine +
    $"Малый остаток: {shoes.IsLowStock()}";
}

private readonly List<Product> _products = new List<Product>();
private void btnLoadCatalog_Click(object? sender, EventArgs e)
{
if (_products.Count == 0)
{
    _products.Add(new Product("Кроссовки", "SportLine",
        "Спортивная", 4000m, 2));
    _products.Add(new Product("Ботинки", "NordStep",
        "Зимняя", 5200m, 7));
    _products.Add(new Product("Сандалии", "Sunny",
        "Летняя", 2500m, 0));
}

lstCatalog.Items.Clear();

foreach (Product item in _products)
{
    lstCatalog.Items.Add(
        $"{item.Name} — {item.Price:N2} ₽ — {item.Stock} шт.");
}

lblCatalogSummary.Text = $"Товарных позиций: {_products.Count}";
}

private void RefreshProductsTable()
{
    dgvProducts.Columns.Clear();
    dgvProducts.Rows.Clear();

    dgvProducts.Columns.Add("Name", "Товар");
    dgvProducts.Columns.Add("Manufacturer", "Производитель");
    dgvProducts.Columns.Add("Category", "Категория");
    dgvProducts.Columns.Add("Price", "Цена со скидкой 25%");
    dgvProducts.Columns.Add("Stock", "Остаток");

    foreach (Product item in _products)
    {
        int index = dgvProducts.Rows.Add(
            item.Name, item.Manufacturer, item.Category,
            $"{item.GetDiscountedPrice(25m):N2} ₽", item.Stock);

        dgvProducts.Rows[index].Tag = item;

        if (item.IsLowStock())
        {
            dgvProducts.Rows[index].DefaultCellStyle.BackColor =
                System.Drawing.Color.MistyRose;
        }
    }
}
private void btnShowTable_Click(object sender, EventArgs e)
{
    if (_products.Count == 0)
    {
        MessageBox.Show("Сначала загрузите товары кнопкой каталога");
        return;
    }

    RefreshProductsTable();
}
private void btnDetails_Click(object? sender, EventArgs e)
{
if (dgvProducts.CurrentRow?.Tag is not Product selected)
{
    MessageBox.Show("Сначала выберите товар в таблице");
    return;
}

using (ProductDetailsForm details = new ProductDetailsForm(selected))
{
    details.ShowDialog(this);
}
}

}