namespace ShoeStoreTraining;
public partial class Form1 : Form
{
public Form1() { InitializeComponent();  }
private void btnStart_Click(object? sender, EventArgs e)
{
lblOutput.Text = "Приложение работает!"; btnStart.Text = "Готово";
}
private void btnShowProduct_Click(object? sender, EventArgs e)
{
string name = txtProductName.Text.Trim();

if (string.IsNullOrWhiteSpace(name))
{
    lblOutput.Text = "Ошибка: укажите название товара";
    return;
}

lblOutput.Text = $"Товар: {name}";
}

}