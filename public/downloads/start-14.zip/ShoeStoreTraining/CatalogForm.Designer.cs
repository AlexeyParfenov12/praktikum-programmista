#nullable enable
namespace ShoeStoreTraining;
partial class CatalogForm
{
private System.ComponentModel.IContainer? components = null;
protected override void Dispose(bool disposing) { if (disposing) components?.Dispose(); base.Dispose(disposing); }
private void InitializeComponent()
{
SuspendLayout();
btnShowProduct = new Button();
btnShowProduct.Name = "btnShowProduct";
btnShowProduct.Location = new Point(20, 20);
btnShowProduct.Size = new Size(430, 35);
btnShowProduct.Text = "Показать товар";
btnShowProduct.Click += btnShowProduct_Click;
Controls.Add(btnShowProduct);
lblCatalogResult = new Label();
lblCatalogResult.Name = "lblCatalogResult";
lblCatalogResult.Location = new Point(480, 20);
lblCatalogResult.Size = new Size(430, 85);
lblCatalogResult.Text = "lblCatalogResult";
Controls.Add(lblCatalogResult);
lstCatalog = new ListBox();
lstCatalog.Name = "lstCatalog";
lstCatalog.Location = new Point(20, 125);
lstCatalog.Size = new Size(430, 80);
Controls.Add(lstCatalog);
btnLoadCatalog = new Button();
btnLoadCatalog.Name = "btnLoadCatalog";
btnLoadCatalog.Location = new Point(480, 125);
btnLoadCatalog.Size = new Size(430, 35);
btnLoadCatalog.Text = "Загрузить каталог";
btnLoadCatalog.Click += btnLoadCatalog_Click;
Controls.Add(btnLoadCatalog);
lblCatalogSummary = new Label();
lblCatalogSummary.Name = "lblCatalogSummary";
lblCatalogSummary.Location = new Point(20, 230);
lblCatalogSummary.Size = new Size(430, 85);
lblCatalogSummary.Text = "lblCatalogSummary";
Controls.Add(lblCatalogSummary);
btnShowTable = new Button();
btnShowTable.Name = "btnShowTable";
btnShowTable.Location = new Point(480, 230);
btnShowTable.Size = new Size(430, 35);
btnShowTable.Text = "Показать таблицу";
btnShowTable.Click += btnShowTable_Click;
Controls.Add(btnShowTable);
dgvProducts = new DataGridView();
dgvProducts.Name = "dgvProducts";
dgvProducts.Location = new Point(20, 335);
dgvProducts.Size = new Size(430, 180);
dgvProducts.AllowUserToAddRows = false;
dgvProducts.ReadOnly = true;
dgvProducts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
dgvProducts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
dgvProducts.Size = new Size(890, 220);
dgvProducts.Location = new Point(20, 440);
Controls.Add(dgvProducts);
lblSelectedProduct = new Label();
lblSelectedProduct.Name = "lblSelectedProduct";
lblSelectedProduct.Location = new Point(480, 335);
lblSelectedProduct.Size = new Size(430, 85);
lblSelectedProduct.Text = "lblSelectedProduct";
Controls.Add(lblSelectedProduct);
AutoScroll = true;
ClientSize = new Size(960, 700);
Text = "CatalogForm — восстановительная база";
ResumeLayout(false);
}
private Button btnShowProduct = null!;
private Label lblCatalogResult = null!;
private ListBox lstCatalog = null!;
private Button btnLoadCatalog = null!;
private Label lblCatalogSummary = null!;
private Button btnShowTable = null!;
private DataGridView dgvProducts = null!;
private Label lblSelectedProduct = null!;
}