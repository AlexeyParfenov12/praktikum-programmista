namespace ShoeStoreTraining;
public partial class Form1 : Form
{
public Form1() { InitializeComponent();  }
private void btnStart_Click(object? sender, EventArgs e)
{
lblOutput.Text = "Приложение работает!"; btnStart.Text = "Готово";
}
private void btnShowProduct_Click(object? sender, EventArgs e)
{
string name = txtProductName.Text.Trim();

if (string.IsNullOrWhiteSpace(name))
{
    lblOutput.Text = "Ошибка: укажите название товара";
    return;
}

lblOutput.Text = $"Товар: {name}";
}
private void btnProductInfo_Click(object? sender, EventArgs e)
{
string name = txtProductName.Text.Trim();
decimal price = nudPrice.Value;
int quantity = (int)nudQuantity.Value;

lblOutput.Text =
    $"Товар: {name}; цена: {price:N2} ₽; количество: {quantity} шт.";
}
private void btnTotal_Click(object? sender, EventArgs e)
{
decimal price = nudPrice.Value;
int quantity = (int)nudQuantity.Value;
decimal discount = nudDiscount.Value;

decimal subtotal = price * quantity;
decimal discountSum = subtotal * discount / 100m;
decimal total = subtotal - discountSum;

total = decimal.Round(total, 2, MidpointRounding.AwayFromZero);

lblTotal.Text =
    $"Без скидки: {subtotal:N2} ₽; скидка: {discountSum:N2} ₽; итог: {total:N2} ₽";
}

}