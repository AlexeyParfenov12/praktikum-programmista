namespace ShoeStoreTraining;
public partial class CatalogForm : Form
{
public CatalogForm() { InitializeComponent();  }
private void btnShowProduct_Click(object? sender, EventArgs e)
{
Product shoes = new Product(
    "Кроссовки", "SportLine", "Спортивная", 4000m, 5);

decimal finalPrice = shoes.GetDiscountedPrice(25m);
bool sold = shoes.TrySell(2);

lblCatalogResult.Text =
    $"Цена со скидкой: {finalPrice:N2} ₽" + Environment.NewLine +
    $"Продажа выполнена: {sold}" + Environment.NewLine +
    $"Остаток: {shoes.Stock}" + Environment.NewLine +
    $"Малый остаток: {shoes.IsLowStock()}";
}

}