#nullable enable
namespace ShoeStoreTraining;
partial class Form1
{
private System.ComponentModel.IContainer? components = null;
protected override void Dispose(bool disposing) { if (disposing) components?.Dispose(); base.Dispose(disposing); }
private void InitializeComponent()
{
SuspendLayout();
lblTitle = new Label();
lblTitle.Name = "lblTitle";
lblTitle.Location = new Point(20, 20);
lblTitle.Size = new Size(430, 85);
lblTitle.Text = "Учебный проект";
Controls.Add(lblTitle);
btnStart = new Button();
btnStart.Name = "btnStart";
btnStart.Location = new Point(480, 20);
btnStart.Size = new Size(430, 35);
btnStart.Text = "Запустить";
btnStart.Click += btnStart_Click;
Controls.Add(btnStart);
lblOutput = new Label();
lblOutput.Name = "lblOutput";
lblOutput.Location = new Point(20, 125);
lblOutput.Size = new Size(430, 85);
lblOutput.Text = "Здесь появится результат";
Controls.Add(lblOutput);
AutoScroll = true;
ClientSize = new Size(960, 700);
Text = "Form1 — восстановительная база";
ResumeLayout(false);
}
private Label lblTitle = null!;
private Button btnStart = null!;
private Label lblOutput = null!;
}