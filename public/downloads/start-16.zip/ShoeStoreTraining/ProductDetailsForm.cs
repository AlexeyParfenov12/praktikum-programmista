namespace ShoeStoreTraining;
public partial class ProductDetailsForm : Form
{
public ProductDetailsForm() { InitializeComponent();  }
public ProductDetailsForm(Product product) : this()
{
    lblDetails.Text =
        $"Наименование: {product.Name}" + Environment.NewLine +
        $"Производитель: {product.Manufacturer}" + Environment.NewLine +
        $"Категория: {product.Category}" + Environment.NewLine +
        $"Обычная цена: {product.Price:N2} ₽" + Environment.NewLine +
        $"Цена со скидкой: {product.GetDiscountedPrice(25m):N2} ₽" + Environment.NewLine +
        $"Остаток: {product.Stock} шт.";
}
private void btnClose_Click(object? sender, EventArgs e)
{
Close();
}

}