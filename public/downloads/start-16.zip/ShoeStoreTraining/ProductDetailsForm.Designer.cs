#nullable enable
namespace ShoeStoreTraining;
partial class ProductDetailsForm
{
private System.ComponentModel.IContainer? components = null;
protected override void Dispose(bool disposing) { if (disposing) components?.Dispose(); base.Dispose(disposing); }
private void InitializeComponent()
{
SuspendLayout();
lblDetails = new Label();
lblDetails.Name = "lblDetails";
lblDetails.Location = new Point(20, 20);
lblDetails.Size = new Size(430, 85);
lblDetails.Text = "lblDetails";
Controls.Add(lblDetails);
lblStatus = new Label();
lblStatus.Name = "lblStatus";
lblStatus.Location = new Point(480, 20);
lblStatus.Size = new Size(430, 85);
lblStatus.Text = "lblStatus";
Controls.Add(lblStatus);
btnClose = new Button();
btnClose.Name = "btnClose";
btnClose.Location = new Point(20, 125);
btnClose.Size = new Size(430, 35);
btnClose.Text = "Закрыть";
btnClose.Click += btnClose_Click;
Controls.Add(btnClose);
lblDetails.Size = new Size(850, 250);
lblStatus.Text = "";
lblStatus.Location = new Point(20,290);
btnClose.Location = new Point(20,400);
AutoScroll = true;
ClientSize = new Size(960, 700);
Text = "ProductDetailsForm — восстановительная база";
ResumeLayout(false);
}
private Label lblDetails = null!;
private Label lblStatus = null!;
private Button btnClose = null!;
}