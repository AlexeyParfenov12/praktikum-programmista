namespace ShoeStoreTraining;

public class Product
{
    public string Name { get; }
    public string Manufacturer { get; }
    public string Category { get; }
    public decimal Price { get; private set; }
    public int Stock { get; private set; }

    public Product(string name, string manufacturer,
        string category, decimal price, int stock)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("Введите название");
        if (price <= 0m)
            throw new ArgumentException("Цена должна быть положительной");
        if (stock < 0)
            throw new ArgumentException("Остаток не может быть отрицательным");

        Name = name.Trim();
        Manufacturer = manufacturer.Trim();
        Category = category.Trim();
        Price = price;
        Stock = stock;
    }

    public decimal GetDiscountedPrice(decimal percent)
    {
        if (percent < 0m || percent > 100m)
            throw new ArgumentException("Скидка вне диапазона 0–100");

        return decimal.Round(Price * (100m - percent) / 100m,
            2, MidpointRounding.AwayFromZero);
    }

    public bool IsLowStock()
    {
        return Stock <= 3;
    }

    public bool TrySell(int quantity)
    {
        if (quantity <= 0 || quantity > Stock)
            return false;

        Stock -= quantity;
        return true;
    }
}